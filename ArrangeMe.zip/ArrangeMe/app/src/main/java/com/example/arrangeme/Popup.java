package com.example.arrangeme;

public interface Popup {
   void definePopUpSize();
   void disableViews();
   void showDetails();
   void showImage();
   void editMode();
}
