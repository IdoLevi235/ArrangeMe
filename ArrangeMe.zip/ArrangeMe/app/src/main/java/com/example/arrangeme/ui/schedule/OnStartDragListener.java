package com.example.arrangeme.ui.schedule;

import androidx.recyclerview.widget.RecyclerView;

public interface OnStartDragListener {
    void requestDrag(RecyclerView.ViewHolder viewHolder);

}
